# Summer Reading Web App 
Built using Google Books API and vue.js
